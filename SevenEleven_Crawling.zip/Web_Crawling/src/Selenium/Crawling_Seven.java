package Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import java.time.Duration;
import org.openqa.selenium.By;
import java.util.Scanner;
import org.openqa.selenium.JavascriptExecutor;
import java.util.ArrayList;
import java.util.List;


public class Crawling_Seven {

	private static WebDriver driver;
	private String url;


	public static final String WEB_DRIVER_ID = "webdriver.chrome.driver";
	public static final String WEB_DRIVER_PATH = "C:\\chrome\\chromedriver.exe";
	
	private final String Seven_company = "SevenEleven";
	
	public Crawling_Seven() {
		try {
			System.setProperty(WEB_DRIVER_ID, WEB_DRIVER_PATH);
		}	
		catch (Exception e) {
			e.printStackTrace();
		}
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");           
		options.addArguments("--disable-popup-blocking");   
		
		driver = new ChromeDriver(options);
	}
	
	public int init() {
		Scanner scanner = new Scanner(System.in);	  
		System.out.print("(SevenEleven - 3번)링크 번호 입력 : ");
		int url_num = scanner.nextInt();
		
		if (url_num == 3)
		{
			url = "https://www.7-eleven.co.kr/product/presentList.asp";
		}
		// https://www.7-eleven.co.kr/product/presentList.asp
	       	       
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		System.out.println("시작 페이지 로딩 완료");
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		
		System.out.print("행사 선택 : ");
		int eventmenu = scanner.nextInt();
		
		if (eventmenu == 2) 
		{
			System.out.println("2 + 1 행사 제품");	         
			js.executeScript("window.scrollBy(0,300)");
			
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[1]/ul/li[2]/a")).click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		}
		else
		{
			System.out.println("1 + 1 행사 제품");
			eventmenu = 1;
		}  	      
		scanner.close();	      	       	       
		return eventmenu;	       	       
		
	}	    	    	    
	    
	public void findproduct(int menu) {
		JavascriptExecutor js = (JavascriptExecutor)driver;	       
		js.executeScript("window.scrollBy(0,700)");
		driver.findElement(By.cssSelector("li.btn_more")).click();	   
		
		//////반복해서 more 누르기 /////////////
		while(true) {
			try {
				WebElement btnMore = driver.findElement(By.cssSelector("li.btn_more"));
				btnMore.click();
				Thread.sleep(1500);
			} catch (Exception e) {
				e.printStackTrace();
				break;
			}	       
		}
	       
		
		ArrayList<Product> product_data = new ArrayList<>();   	       		
///////////////////////////< 2 + 1 > //////////////////////
		if (menu == 2) // 2 + 1 행사
		{			
			for(int i=2;;i++) {
				try {
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
					//회사
					String company = Seven_company;
					if(i<15) {
					//이름
					String name = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[2]/div/ul/li[" + (i) + "]/div/div/div[1]")).getText();
					//가격
					String price = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[2]/div/ul/li[" + (i) + "]/div/div/div[2]/span")).getText();
					Product p = new Product(company, name,price);
					System.out.println((i-1)+". "+ name + " (" + price + ")");					
					product_data.add(p);
					System.out.println(product_data.get(i-2) );
					}
					else {
						//이름
						String name = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[2]/div/ul/li[" + (i) + "]/div/div/div/div[1]")).getText();
						//가격
						String price = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[2]/div/ul/li[" + (i) + "]/div/div/div/div[2]/span")).getText();
						Product p = new Product(company, name,price);
						System.out.println((i-1)+". "+ name + " (" + price + ")");					
						product_data.add(p);
						System.out.println(product_data.get(i-2) );
					}		             

				} catch (org.openqa.selenium.NoSuchElementException e) {
					e.printStackTrace();
					break;
				}	       
			}     
		}
		
/////////////// < 1 + 1 > //////////////
		else if(menu == 1) // 1 + 1 행사
		{
			for(int i=2;;i++) {
				try {
					driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
					//회사
					String company = Seven_company;
					if(i<15) {
					//이름
					String name = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[2]/div/ul/li[" + (i) + "]/div/div/div[1]")).getText();
					//가격
					String price = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[2]/div/ul/li[" + (i) + "]/div/div/div[2]/span")).getText();
					Product p = new Product(company, name,price);
					System.out.println((i-1)+". "+ name + " (" + price + ")");					
					product_data.add(p);
					System.out.println(product_data.get(i-2) );
					}
					else {
						//이름
						String name = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[2]/div/ul/li[" + (i) + "]/div/div/div/div[1]")).getText();
						//가격
						String price = driver.findElement(By.xpath("/html/body/div[2]/div[2]/form/div[3]/div[2]/div/ul/li[" + (i) + "]/div/div/div/div[2]/span")).getText();
						Product p = new Product(company, name,price);
						System.out.println((i-1)+". "+ name + " (" + price + ")");					
						product_data.add(p);
						System.out.println(product_data.get(i-2) );
					}		             
				} catch (org.openqa.selenium.NoSuchElementException e) {
					e.printStackTrace();
					break;
				}	       
			} 
		}
	}
	    

	public static void main(String[] args) {
		Crawling_Seven crawl = new Crawling_Seven();
		int menu = crawl.init(); 
		crawl.findproduct(menu);
		System.out.println("끝");
		driver.quit();
	}
}

